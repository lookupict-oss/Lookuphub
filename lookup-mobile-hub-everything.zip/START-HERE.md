# Lookup Mobile Hub: everything in one package

| Zip | What's in it |
|---|---|
| `1-admin-server.zip` | Admin panel, the server/API/database, deploy files, production planning docs |
| `2-android-app.zip` | The Android app project and how to build the APK |
| `3-website.zip` | The website: landing page with app download button, plus the full web app |

How they connect: the website and the Android app both talk to the server in zip 1, so both use the same
accounts and wallets, and everything is visible and controllable from the admin panel.

Order to follow:
1. Deploy the server (zip 1, README-ADMIN.md). You get a server address.
2. Put that address in the app's `config.js` and build the APK (zip 2). Put the APK in the website's `downloads/` folder.
3. The website (zip 3) is already included in the server's `app/` folder. Update it with `npm run sync-app` if you change it.

Honest limits: card funding, SMS codes and vendor delivery still need real providers, and the single-file database is
for launch, not millions of users (see README-ADMIN.md). Tested locally: sign up, fund, purchase, history, admin visibility, suspension.
